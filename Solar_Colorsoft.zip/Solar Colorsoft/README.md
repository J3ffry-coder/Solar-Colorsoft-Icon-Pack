## Solar Colorsoft

Color icon pack for KOReader and SimpleUI, tuned for color e-ink.

https://github.com/J3ffry-coder/Solar-Colorsoft-Icon-Pack


### Install

**KOReader**

Copy the SVG files from `KOReader/icons/` to the `icons` folder in your KOReader data directory, then restart KOReader.


**SimpleUI**

Install `Solar Colorsoft SimpleUI - Install Pack.zip` from **Settings > Style > Icons > Icon Packs > Install pack from ZIP**.


### Credits

Based on Solar Icons by 480 Design and selected KOReader icon resources.

Solar Icons:  
https://github.com/480-Design/Solar-Icon-Set

KOReader:  
https://github.com/koreader/koreader

Solar Colorsoft adaptation: Jeffrey.


### Use

Please don't use my Solar Colorsoft modifications commercially. Original icons created for Solar Colorsoft may not be used commercially without permission. Original icons remain subject to their original licenses.
