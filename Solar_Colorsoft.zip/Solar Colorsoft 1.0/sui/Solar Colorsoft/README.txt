Solar Colorsoft for SimpleUI

A colorful Solar-based icon pack for SimpleUI/KOReader, designed with color e-ink displays in mind.

Installation
In SimpleUI, open Settings > Style > Icons > Icon Packs > Install pack from ZIP and select this ZIP.
Alternatively, place the pack folder/ZIP in the SimpleUI sui_icons/packs directory inside your KOReader settings/data directory.

Credits
Solar Icons by 480 Design, licensed under CC BY 4.0.
Selected artwork/geometry in the wider Solar Colorsoft pack is also based on or adapted from KOReader's original icon resources (KOReader: GNU AGPL v3.0).
Adaptation and Solar Colorsoft design by Jeffrey from Amsterdam.

See the main Solar Colorsoft README/CREDITS for source links and full attribution notes.


Pack contents
- 47 SVG icons total.
- 44 correspond to filenames currently accepted by the supplied SimpleUI icon-pack importer.
- 3 additional action icons are retained for forward compatibility because their actions/settings already exist in the supplied SimpleUI code: sui_action_recent.svg, sui_action_random_document.svg, and sui_action_wifi_toggle_off.svg.
