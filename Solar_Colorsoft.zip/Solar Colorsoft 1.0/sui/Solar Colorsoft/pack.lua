return { name="Solar Colorsoft", author="Jeffrey from Amsterdam", version="1.0" }
